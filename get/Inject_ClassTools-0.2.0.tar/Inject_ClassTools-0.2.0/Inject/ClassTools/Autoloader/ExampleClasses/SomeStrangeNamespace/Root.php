<?php
/*
 * Created by Martin Wernståhl on 2011-04-21.
 * Copyright (c) 2011 Martin Wernståhl.
 * All rights reserved.
 */

namespace Strange;

/**
 * 
 */
class Root
{
	public static function getFile()
	{
		return __FILE__;
	}
}

/* End of file Root.php */
/* Location: src/php/Inject/ClassTools/Autoloader/ExampleClasses/SomeStrangeNamespace */