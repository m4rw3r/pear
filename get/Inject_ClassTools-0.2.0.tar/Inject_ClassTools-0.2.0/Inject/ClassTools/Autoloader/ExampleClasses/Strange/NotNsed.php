<?php
/*
 * Created by Martin Wernståhl on 2011-04-21.
 * Copyright (c) 2011 Martin Wernståhl.
 * All rights reserved.
 */

namespace Strange;

/**
 * 
 */
class NotNsed
{
	public static function getFile()
	{
		return __FILE__;
	}
}

/* End of file NotNsed.php */
/* Location: src/php/Inject/ClassTools/Autoloader/ExampleClasses/Strange */